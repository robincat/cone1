<!DOCTYPE html>
<!--[if IE 8]><html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]>
<!--><html class="no-js" lang="en"><!--<![endif]-->
<head>	
</head>
<body>	
	
	<!-- PROJECT SECTION
    ================================================== -->


		<?php while (have_posts()) : the_post()?>
			<?php the_content(); ?>
		<?php endwhile; ?>

		
<!-- End Document
================================================== -->
</body>
</html>