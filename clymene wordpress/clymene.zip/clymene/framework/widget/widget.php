<?php

	require_once('socials.php');

	require_once('logo-footer.php');

?>
