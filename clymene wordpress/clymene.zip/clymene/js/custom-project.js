(function($) { "use strict";  
	var elements = document.querySelectorAll( '.big-image' );
	Intense( elements );
})(jQuery);
